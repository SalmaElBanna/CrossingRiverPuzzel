package Logic;

import save_load.Game;
import save_load.Progress;
import save_load.Progress2;
import memento.Memento;
import memento.RedoCaretaker;
import memento.UndoCaretaker;
import memento.Originator;
import java.util.List;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
public class Controller implements IRiverCrossingControl {

	@Override
	public void newGame(ICrossingStrategy gameStrategy) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resetGame() {
		if(s1)
                    story1.delete();
                else if(s2)
                    story2.delete();	
	}

	@Override
	public String[] getInstructions() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ICrosser> getCrossersOnRightBank() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ICrosser> getCrossersOnLeftBank() {
		// TODO Auto-generated method stub
		return null;
	}

        
	@Override
	public boolean isBoatOnLeftBank() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getNumOfSails() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean canMove(List<ICrosser> crossers, boolean fromLeftToRightBank) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean doMove(List<ICrosser> crossers, boolean fromLeftToRightBank) {
		// TODO Auto-generated method stub
		return false;
	}

        
        RedoCaretaker re = new RedoCaretaker();
        UndoCaretaker un = new UndoCaretaker();
        Stack<Memento> r = new Stack<>();
        Stack<Memento> u = new Stack<>();
        Originator originator = new Originator();
        Game game;
               
	@Override
	public boolean canUndo() {
            return !un.empty(); 
	}

	@Override
	public boolean canRedo() {
            return !re.empty(); 
	}

	@Override
	public void undo() {
            originator.setState(un.getMemento().getState());
            re. addMemento(originator.saveStateToMemento());
	}

	@Override
	public void redo() {
	     originator.setState(re.getMemento().getState());
             un.addMemento(originator.saveStateToMemento());	
	}

        Progress story1;
        Progress2 story2;

        public void setStory1(Progress story1) {
            this.story1 = story1;
        }

        public void setStory2(Progress2 story2) {
            this.story2 = story2;
        }
    
        boolean s1;
        boolean s2;

        public void setS1(boolean s1) {
            this.s1 = s1;
        }

        public void setS2(boolean s2) {
            this.s2 = s2;
        }
    
	@Override
	public void saveGame() {
	      if(s1)
                  try {
                      story1.SaveProgress();
              } catch (TransformerException ex) {
                  Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
              }
              else try {
                  story2.SaveProgress();
              } catch (TransformerException ex) {
                  Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
              }
	}

	@Override
	public void loadGame() {
            if(s1)
                try {
                    game= story1.getGprogress();
            } catch (ParserConfigurationException ex) {
                Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
            }
            else try {
                game = story2.getGprogress();
            } catch (ParserConfigurationException ex) {
                Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
            }	
	}

	@Override
	public List<List<ICrosser>> solveGame() {
		// TODO Auto-generated method stub
		return null;
	}

}
