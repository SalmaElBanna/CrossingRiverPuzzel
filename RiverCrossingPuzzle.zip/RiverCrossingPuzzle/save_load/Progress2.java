/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package save_load;

import Logic.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author Salma
 */
public class Progress2 {
    
    public static Game g;
  
    public Progress2(Game g) {
        Progress2.g = g; 
    }

    public Progress2() {
    }
    
    public void SaveProgress() throws TransformerException  {
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.newDocument();
            //
            // root element
            Element rootElement = doc.createElement("story2");
            doc.appendChild(rootElement);
            //
            // numofmoves element
            Element numofmoves = doc.createElement("numofmoves");
            rootElement.appendChild(numofmoves);
            //
            // lefttbankposition element
            Element leftbankposition = doc.createElement("leftbankposition");
            rootElement.appendChild(leftbankposition);

            numofmoves.setTextContent(Integer.toString(g.score));

            if (g.onleftbank) {
                leftbankposition.setTextContent("true");
            } else {
                leftbankposition.setTextContent("false"); 
            }
            //
            // getting characters on the right bank
            int i = 0;
            String weight = "weight";
            while (i < g.righttbank.size() ) {
                Element rightchars = doc.createElement("rightchars");
                rightchars.setAttribute(weight, Double.toString(g.righttbank.get(i).getWeight()));
                if (g.righttbank.get(i) instanceof Fox) {
                    rightchars.setTextContent("Fox"); 
                } else if (g.righttbank.get(i) instanceof Cabbage) {
                    rightchars.setTextContent("Cabage");
                } else if (g.righttbank.get(i) instanceof Carrots) {
                    rightchars.setTextContent("Carrots");
                } else if (g.righttbank.get(i) instanceof Farmer) {
                    rightchars.setTextContent("Farmer");
                } else if (g.righttbank.get(i) instanceof Goat) {
                    rightchars.setTextContent("Goat");
                } else if (g.righttbank.get(i) instanceof Lion) {
                    rightchars.setTextContent("Lion");
                } else if (g.righttbank.get(i) instanceof Rabbit) {
                    rightchars.setTextContent("Rabbit");
                }
                rootElement.appendChild(rightchars);
                i++; 
            }
            //
            // getting characters on the left bank
            i = 0;
            while (i < g.leftbank.size() ) {
                Element leftchars = doc.createElement("leftchars");
                leftchars.setAttribute(weight, Double.toString(g.leftbank.get(i).getWeight()));
                if (g.leftbank.get(i) instanceof Fox) {
                    leftchars.setTextContent("Fox");
                } else if (g.leftbank.get(i) instanceof Cabbage) {
                    leftchars.setTextContent("Cabage");
                } else if (g.leftbank.get(i) instanceof Carrots) {
                    leftchars.setTextContent("Carrots");
                } else if (g.leftbank.get(i) instanceof Farmer) {
                    leftchars.setTextContent("Farmer");
                } else if (g.leftbank.get(i) instanceof Goat) {
                    leftchars.setTextContent("Goat");
                } else if (g.leftbank.get(i) instanceof Lion) {
                    leftchars.setTextContent("Lion");
                } else if (g.leftbank.get(i) instanceof Rabbit) {
                    leftchars.setTextContent("Rabbit");
                }
                rootElement.appendChild(leftchars);
                i++;
            }
            //
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File("story2.xml"));
            transformer.transform(source, result);
            //
            // printing result
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(Progress.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    public Game getGprogress() throws ParserConfigurationException
    {
        try {
            ArrayList<ICrosser> lbcrosser = new ArrayList<>();
            ArrayList<ICrosser> rbcrosser = new ArrayList<>();
            int score = 0;
            boolean pos = false;
            Fox f = new Fox();
            Cabbage cab = new Cabbage();
            Carrots car =new Carrots();
            Goat go = new Goat();
            Lion le = new Lion();
            Rabbit bunny = new Rabbit();
            File inputFile = new File("story2.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            
            NodeList Listleft = doc.getElementsByTagName("leftchars");
            NodeList Listright = doc.getElementsByTagName("rightchars");
            
            int j;
            for(j=0; j< Listleft.getLength() ; j++)
            {
                Node node = Listleft.item(j);
                Element e = (Element)node;
                String str = node.getTextContent();
                if(str.equalsIgnoreCase("Fox"))
                    lbcrosser.add(f);
                else if(str.equalsIgnoreCase("Farmer"))
                {
                    double d;
                    d= Double.parseDouble(e.getAttribute("weight"));
                    Farmer fa = new Farmer(d);
                    lbcrosser.add(fa);    
                }
                else if(str.equalsIgnoreCase("Carrot"))
                    lbcrosser.add(car);
                else if(str.equalsIgnoreCase("Cabbage"))
                    lbcrosser.add(cab);
                else if(str.equalsIgnoreCase("Rabbit"))
                    lbcrosser.add(bunny);
                else if(str.equalsIgnoreCase("Goat"))
                    lbcrosser.add(go);
                else if(str.equalsIgnoreCase("Lion"))
                    lbcrosser.add(le);
            }
            
            for(j=0; j< Listright.getLength() ; j++)
            {
                Node node = Listright.item(j);
                Element e = (Element)node;
                String str = node.getTextContent();
                if(str.equalsIgnoreCase("Fox"))
                    rbcrosser.add(f);
                else if(str.equalsIgnoreCase("Farmer"))
                {
                   double d;
                   d= Double.parseDouble(e.getAttribute("weight"));
                   Farmer fa = new Farmer(d);
                   rbcrosser.add(fa);
                }
                    
                else if(str.equalsIgnoreCase("Carrot"))
                    rbcrosser.add(car);
                else if(str.equalsIgnoreCase("Cabbage"))
                    rbcrosser.add(cab);
                else if(str.equalsIgnoreCase("Rabbit"))
                    rbcrosser.add(bunny);
                else if(str.equalsIgnoreCase("Goat"))
                    rbcrosser.add(go);
                else if(str.equalsIgnoreCase("Lion"))
                    rbcrosser.add(le);
            }
            
            NodeList placeplace = doc.getElementsByTagName("leftbankposition");
            
            for(j=0;j<placeplace.getLength();j++)
            {
                Node n = placeplace.item(j);
                String str = n.getTextContent();
                pos = str.equalsIgnoreCase("true"); 
            }
            
            NodeList mylist = doc.getElementsByTagName("numofmoves");
            
            for(j=0; j<mylist.getLength(); j++)
            {
                Node node = mylist.item(j);
                String str = node.getTextContent();
                score = Integer.parseInt(str);
            }

           Game game = new Game(score, pos,lbcrosser, rbcrosser);
           return game;
        } catch (SAXException | IOException ex) {
            Logger.getLogger(Progress.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public void delete()
    {
        File f = new File("story2.xml");
        f.delete();
    }
}
    
