package GUI;

import java.awt.Dimension;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

import Logic.Controller;
import Logic.Receiver;
import Logic.Commands.Command;
import Logic.Commands.ResetGameCommand;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class SettingsLayout {
	
	private Stage window;
	private Stage primaryStage;
	private Scene scene;
	
	//Buttons
	private Button resumeButton;
	private Button restartButton;
	private Button instructionsButton;
	private Button exitButton;
	
	//Layouts
	private MainMenuLayout mainMenuLayout;
	private GameLayout gameLayout;
	private LevelsLayout levelsLayout;
	
	//Receiver and Controller
	private Receiver receiver=Receiver.getInstance();
	private Controller controller=new Controller();
	
	//Sprites
	private List<Sprite> boatSprites;
	private List<Sprite> rightSprites;
	private Sprite boat;
	
	//labels
	private List<Label> rightLabels;
	private List<Label> boatLabels;
	
	//Group
	private Group group;
	
	
	public SettingsLayout(Stage primaryStage,Dimension screenSize) {
		this.primaryStage=primaryStage;
		try {
			levelsLayout=new LevelsLayout(primaryStage,screenSize);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void display()
	{
		window=new Stage();
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle("Settings");
		try {
			window.getIcons().add(new Image(new FileInputStream("src\\resources\\Icons\\gear (1).png")));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		VBox layout=new VBox();
		layout.setAlignment(Pos.CENTER);
		layout.setSpacing(20);

		addButtons(layout);
		setButtonsActions();
		
		scene=new Scene(layout,400,300);
		window.setScene(scene);
		window.showAndWait();
	}
	
	public void addButtons(VBox layout) {
		Background buttonBackground =new Background(new BackgroundFill(Color.WHITE,CornerRadii.EMPTY, Insets.EMPTY));
		
		//resume Button
		resumeButton=new Button("Resume Game");
		resumeButton.setBackground(buttonBackground);
		resumeButton.setFont(Font.font(16));
		resumeButton.setMinWidth(120);
		resumeButton.setMinHeight(50);
		
		//restart Button
		restartButton=new Button("Restart Game");
		restartButton.setBackground(buttonBackground);
		restartButton.setFont(Font.font(16));
		restartButton.setMinWidth(120);
		restartButton.setMinHeight(50);
		
		//instructions Button
		instructionsButton=new Button("Instructions");
		instructionsButton.setBackground(buttonBackground);
		instructionsButton.setFont(Font.font(16));
		instructionsButton.setMinWidth(120);
		instructionsButton.setMinHeight(50);
		
		//exit Button
		exitButton=new Button("Exit");
		exitButton.setBackground(buttonBackground);
		exitButton.setFont(Font.font(16));
		exitButton.setMinWidth(120);
		exitButton.setMinHeight(50);
		
		layout.getChildren().addAll(resumeButton,restartButton,instructionsButton,exitButton);	
	}
	
	public void setButtonsActions() {
		
		//Resume Button
		resumeButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				window.close();
			}
		});
		
		//Restart Button
		restartButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				Story1Layout s1=null;
				Story2Layout s2=null;
				int i;
				
				//getting the sprites and labels
				if(gameLayout instanceof Story1Layout) {
					s1=(Story1Layout)gameLayout;
					boatSprites=s1.getBoatSprites();
					rightSprites=s1.getRightSprites();
					
					rightLabels=s1.getRightLabels();
					boatLabels=s1.getBoatLabels();
					
					group=s1.getGroup();
				}
				else if(gameLayout instanceof Story2Layout) {
					s2=(Story2Layout)gameLayout;
					boatSprites=s2.getBoatSprites();
					rightSprites=s2.getRightSprites();
					
					rightLabels=s2.getRightLabels();
					boatLabels=s2.getBoatLabels();
					
					group=s2.getGroup();
				}
				
				//rendering the boat riders
				if(receiver.isBoatOnLeftBank()) {
					for(i=0;i<boatSprites.size();i++) {
						boatSprites.get(i).removeLeftBoatImageView(group);
						boatSprites.get(i).renderLeftImageView(group);		
						boatLabels.get(i).setLayoutX(boatSprites.get(i).getPositionXleft()+boatSprites.get(i).getWidth()/2-20);
						boatLabels.get(i).setLayoutY(boatSprites.get(i).getPositionYleft()+boatSprites.get(i).getHeight());
					}
				}
				else {
					boat=gameLayout.getBoat();
					boat.hideRightImageView();
					boat.viewLeftImageView();
					
					for(i=0;i<boatSprites.size();i++) {
						boatSprites.get(i).removeRightBoatImageView(group);
						boatSprites.get(i).renderLeftImageView(group);
						
						boatLabels.get(i).setLayoutX(boatSprites.get(i).getPositionXleft()+boatSprites.get(i).getWidth()/2-20);
						boatLabels.get(i).setLayoutY(boatSprites.get(i).getPositionYleft()+boatSprites.get(i).getHeight());
					}
				}
				
				//rendering the right bank crossers
				for(i=0;i<rightSprites.size();i++) {
					rightSprites.get(i).removeRightImageView(group);
					rightSprites.get(i).renderLeftImageView(group);
					
					rightLabels.get(i).setLayoutX(rightSprites.get(i).getPositionXleft()+rightSprites.get(i).getWidth()/2-20);
					rightLabels.get(i).setLayoutY(rightSprites.get(i).getPositionYleft()+rightSprites.get(i).getHeight());
				}
				
				ResetGameCommand command=new ResetGameCommand(receiver);
				controller.setCommand(command);
				controller.performCommand();
				
				if(gameLayout instanceof Story1Layout) {
					s1.reset();
				}
				else if(gameLayout instanceof Story2Layout) {
					s2.reset();
				}
				
				window.close();
				
			}
		}); 
		
		//not good as there will be duplicates and we'll have to remove them all
	/**	restartButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				Story1Layout s1=null;
				Story2Layout s2=null;
				int i;
				receiver.resetGame();
				if(gameLayout instanceof Story1Layout) {
					s1=(Story1Layout)gameLayout;
					s1.reset2();
				}
				
			}
		});*/
		
		//Instructions Button
		instructionsButton.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				gameLayout.showInstructions();
			}
			
		});
		
		//Exit Button
		exitButton.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				Alert alert = new Alert(AlertType.NONE);
				alert.setContentText("Are you sure you want to exit?");
				alert.setTitle("Exit");
				
				ButtonType yesButton = new ButtonType("Yes", ButtonData.YES);
				ButtonType noButton = new ButtonType("No", ButtonData.CANCEL_CLOSE);
				
				alert.getButtonTypes().setAll(yesButton,noButton);
				Optional<ButtonType> result = alert.showAndWait();
				if(result.get()==yesButton) {
					mainMenuLayout.setLevelsLayout(levelsLayout);
					levelsLayout.setMainMenuLayout(mainMenuLayout);
					primaryStage.setScene(mainMenuLayout.getScene());
					window.close();
				}	
			}
			
		});
	}
	
	//setting Layouts
	public void setMainMenuLayout(MainMenuLayout mainMenuLayout) {
		this.mainMenuLayout = mainMenuLayout;
	}
	
	public void setGameLayout(GameLayout gameLayout) {
		this.gameLayout = gameLayout;
	}


}
