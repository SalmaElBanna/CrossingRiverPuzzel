package GUI;

import javafx.scene.Group;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.*;


public class Sprite {
	
	//related to imageViews (characters)
	private ImageView leftImageView;
	private final double positionXleft;
	private final double positionYleft;
	
	private ImageView rightImageView;
	private final double positionXright;
	private final double positionYright;
	
	private ImageView leftBoatImageView;
	
	private ImageView rightBoatImageView;
	
	private final double positionYBoat;
	/////////////////////////////////////

	//related to normal images
	private Image leftImage;
    private Image rightImage;
    private double positionX;
    private double positionY;
    private double width;
    private double height;
    ////////////////////////////
    
    //constants of positions of characters on boat
    private double xBoatLeft1=520;
    private double xBoatLeft2=645;
    private double xBoatRight1=730;
    private double xBoatRight2=600;
    
    //Constructor for the boat
    public Sprite(ImageView leftImageView,ImageView rightImageView) {
    	//left image
		this.leftImageView=leftImageView;
		this.positionXleft=500;
		this.positionYleft=300;

		//right image
		this.rightImageView=rightImageView;
		this.positionXright=600;
		this.positionYright=300;
		
		//unused in this case
		this.positionYBoat=0;
    }
    
    //Constructor using imageViews(example for characters)
    public Sprite(ImageView leftImageView,double leftX,double leftY,ImageView rightImageView
    		,ImageView leftBoatImageView,ImageView rightBoatImageView,double yBoat,double rightX
    		,double width,double height) {
    	//left image
		this.leftImageView=leftImageView;
		this.positionXleft=leftX;
		this.positionYleft=leftY;

		//right image
		this.rightImageView=rightImageView;
		this.positionYright=leftY;
		this.positionXright=rightX;
		
		//left boat image
		this.leftBoatImageView=leftBoatImageView;

		//right boat image
		this.rightBoatImageView=rightBoatImageView;
		
		this.positionYBoat=yBoat;
		
		this.height=height;
		this.width=width;

	}
    
    //draw the image
     public void renderLeft(GraphicsContext gc)
     {
       gc.drawImage(leftImage, positionX, positionY);
     }
     
     public void renderRight(GraphicsContext gc)
     {
       gc.drawImage(rightImage, positionX, positionY);
     }
     //delete the image
     public void deleteLeft(GraphicsContext gc) {
    	 
     }
     
     /////////////draw the imageView////////////////////
     public void renderLeftImageView(Group group) {
    	leftImageView.setLayoutX(positionXleft);
    	leftImageView.setLayoutY(positionYleft);
		group.getChildren().add(leftImageView);
     }
     
     public void renderRightImageView(Group group) {
    	 rightImageView.setLayoutX(positionXright);
    	 rightImageView.setLayoutY(positionYright);
		 group.getChildren().add(rightImageView);
     }
     
     ///////////////draw imageView on Boat//////////////
     public void drawCharacter1Left(Group group) {
    	 leftBoatImageView.setLayoutX(xBoatLeft1);
    	 leftBoatImageView.setLayoutY(positionYBoat);
    	 group.getChildren().add(leftBoatImageView);
     }
     
     public void drawCharacter2Left(Group group) {
    	 leftBoatImageView.setLayoutX(xBoatLeft2);
    	 leftBoatImageView.setLayoutY(positionYBoat);
    	 group.getChildren().add(leftBoatImageView);
     }
     
     public void drawCharacter1Right(Group group) {
    	 rightBoatImageView.setLayoutX(xBoatRight1);
    	 rightBoatImageView.setLayoutY(positionYBoat);
    	 group.getChildren().add(rightBoatImageView);
     }
     public void drawCharacter2Right(Group group) {
      	 rightBoatImageView.setLayoutX(xBoatRight2);
    	 rightBoatImageView.setLayoutY(positionYBoat);
    	 group.getChildren().add(rightBoatImageView);
     }
     
     
     //////////////remove the imageView////////////////
     public void removeLeftImageView(Group group) {
    	 group.getChildren().remove(leftImageView);
     }
     
     public void removeLeftBoatImageView(Group group) {
    	 group.getChildren().remove(leftBoatImageView);
     }
     
     public void removeRightImageView(Group group) {
    	 group.getChildren().remove(rightImageView);
     }
     
     public void removeRightBoatImageView(Group group) {
    	 group.getChildren().remove(rightBoatImageView);
     }
     
     //Hide the image view
     public void hideLeftImageView() {
    	 leftImageView.setVisible(false);
     }
     public void hideRightImageView() {
    	 rightImageView.setVisible(false);
     }
     
     //view image view
     public void viewLeftImageView() {
    	 leftImageView.setVisible(true);
     }
     
     public void viewRightImageView() {
    	 rightImageView.setVisible(true);
     }
     
     /////////getters for imageViews///////////////
     public ImageView getLeftImageView() {
		return leftImageView;
	}
     
     public ImageView getRightImageView() {
		return rightImageView;
	}
     
     //getters
     public double getPositionXleft() {
		return positionXleft;
	}
     
     public double getPositionXright() {
		return positionXright;
	}
     
     public double getxBoatLeft1() {
		return xBoatLeft1;
	}
     
     public double getxBoatLeft2() {
		return xBoatLeft2;
	}
     
     public double getxBoatRight1() {
		return xBoatRight1;
	}
    
     
     public double getxBoatRight2() {
		return xBoatRight2;
	}
     
     public double getPositionYBoat() {
		return positionYBoat;
	}
     
     public double getWidth() {
		return width;
	}
     
     public double getHeight() {
		return height;
	}
     
     public double getPositionYleft() {
		return positionYleft;
	}
     
     public double getPositionYright() {
		return positionYright;
	}
     
     
}
