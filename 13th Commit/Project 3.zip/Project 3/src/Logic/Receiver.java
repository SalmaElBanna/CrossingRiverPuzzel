package Logic;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.xml.sax.SAXException;

import Logic.Crossers.ICrosser;
import Logic.Levels.ICrossingStrategy;
import Logic.Levels.Story1;
import Logic.Levels.Story2;
import Logic.memento.Memento;
import Logic.memento.Originator;
import Logic.memento.RedoCaretaker;
import Logic.memento.UndoCaretaker;
import Logic.save_load.Game;
import Logic.save_load.Load;
import Logic.save_load.Progress;
import Logic.save_load.Progress2;

public class Receiver implements IControl {
	
	private String errorMessage;
	private ICrossingStrategy gameStrategy;
	
	private List <ICrosser> tempLeftCrossers=new ArrayList<>();
	private List <ICrosser> leftCrossers=new ArrayList<>();
	private List <ICrosser> rightCrossers=new ArrayList<>();
	
	//Load
	Load load=new Load();
	
	//score
	private Score score;
	
	private static Receiver receiver;
	//make constructor private
	private Receiver() {
		
	}
	
	public static Receiver getInstance() {
		if(receiver==null)
			receiver=new Receiver();
		return receiver;
	}

	@Override
	public void newGame(ICrossingStrategy gameStrategy) {
		this.gameStrategy=gameStrategy;
		this.leftCrossers.clear();
		 for(int i=0;i<gameStrategy.getInitialCrossers().size();i++) {
			 leftCrossers.add(gameStrategy.getInitialCrossers().get(i));
		 }
		 rightCrossers.clear();
		score=new Score();
		load.delete();
	}

	@Override
	public void resetGame() { 
		undoCareTaker.clearStack();
		redoCareTaker.clearStack();
		this.leftCrossers.clear();
		
		//copying initial crossers to the receiver's
		 for(int i=0;i<gameStrategy.getInitialCrossers().size();i++) {
			 leftCrossers.add(gameStrategy.getInitialCrossers().get(i));
		}
		this.rightCrossers.clear();
		score.resetScore();	
		load.delete();
	      
	}
	
	@Override
	public String[] getInstructions() {
		return gameStrategy.getInstructions();
	}

	@Override
	public List<ICrosser> getCrossersOnRightBank() {
		return rightCrossers;
	}

	@Override
	public List<ICrosser> getCrossersOnLeftBank() {
		return leftCrossers;
	}

	@Override
	public boolean isBoatOnLeftBank() {
		// dependent on the score (if even: true, otherwise: false)
		if(score.getScore()%2==0)
			return true;
		return false;
	}

	@Override
	public int getNumOfSails() {
		//  dependent on the score
		return score.getScore();
	}
	
	@Override
	public boolean canMove(List<ICrosser> crossers, boolean fromLeftToRightBank) {
		 List <ICrosser> leftBankCrossers=new ArrayList<>();
		 List <ICrosser> rightBankCrossers=new ArrayList<>();
		 int i;
		 
		 
		 //copying real left and right crossers to temporary lists for validation
		 for(i=0;i<leftCrossers.size();i++) {
			 leftBankCrossers.add(leftCrossers.get(i));
		 }
		 
		 for(i=0;i<rightCrossers.size();i++) {
			 rightBankCrossers.add(rightCrossers.get(i));
		 }

	    //adding the boat riders to the temporary lists for validation
		if(fromLeftToRightBank) {
			for(i=0;i<crossers.size();i++) {
				rightBankCrossers.add(crossers.get(i));
				leftBankCrossers.remove(crossers.get(i));
			}
		}
		else {
			for(i=0;i<crossers.size();i++) {
				leftBankCrossers.add(crossers.get(i));
				rightBankCrossers.remove(crossers.get(i));
			}
		}
		//checking if valid move
		return gameStrategy.isValid(rightBankCrossers, leftBankCrossers, crossers);
	}

	@Override
	public void doMove(List<ICrosser> crossers, boolean fromLeftToRightBank) {
		
		//clearing the redoStack after new move
		redoCareTaker.clearStack();
		
		undoOriginator.setState(new Game());
		undoCareTaker.addMemento(undoOriginator.saveStateToMemento());
		
		score.increaseScore();
		
		if(fromLeftToRightBank) {
			for(int i=0;i<crossers.size();i++) {
				rightCrossers.add(crossers.get(i));
				leftCrossers.remove(crossers.get(i));
			}
		}
		else
			for(int i=0;i<crossers.size();i++) {
				leftCrossers.add(crossers.get(i));
				rightCrossers.remove(crossers.get(i));
			}

	}
	////////////////////////////////////////////////////////////////////////////////
	
   private RedoCaretaker redoCareTaker = new RedoCaretaker();
   private UndoCaretaker undoCareTaker = new UndoCaretaker();
   private Originator undoOriginator = new Originator();
   private Originator redoOriginator = new Originator();
   private Game game;

	@Override
	public boolean canUndo() {
		return !undoCareTaker.empty();
	}

	@Override
	public boolean canRedo() {
		return !redoCareTaker.empty();
	}

	@Override
	public void undo() {
		//decreasing the score
		score.decreaseScore();
		
		//getting the last move
		game=undoCareTaker.getMemento().getState();
        undoOriginator.setState(game);
        
        //saving the current state before change
        redoOriginator.setState(new Game());
        redoCareTaker.addMemento(redoOriginator.saveStateToMemento());
        
        //setting the changes
        this.leftCrossers=undoOriginator.getState().getLeftbank();
        this.rightCrossers=undoOriginator.getState().getRighttbank();
        
        saveGame();
 
	}

	@Override
	public void redo() {	
		//increasing the score
		 score.increaseScore();
		 
		//getting the last move
		 game=redoCareTaker.getMemento().getState();
	     redoOriginator.setState(game);
	     
	     //saving the current state before change
	     undoOriginator.setState(new Game());
	     undoCareTaker.addMemento(undoOriginator.saveStateToMemento());
	        
	     this.leftCrossers=redoOriginator.getState().getLeftbank();
	     this.rightCrossers=redoOriginator.getState().getRighttbank();
		 
	     saveGame();
	}
	//////////////////////////////////////////////////////////////////////
	
	private Progress story1;
    private Progress2 story2;

	@Override
	public void saveGame() {
	      if(gameStrategy instanceof Story1)
              try {
            	  story1=new Progress(new Game());
                  story1.SaveProgress();
          } catch (TransformerException ex) {
              Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
          }
          else try {
        	  story2=new Progress2(new Game());
              story2.SaveProgress();
          } catch (TransformerException ex) {
              Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
          }
	}

	@Override
	public void loadGame() {
		undoCareTaker.clearStack();
		redoCareTaker.clearStack();
		
        try {
			game=load.getGprogress();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 
        
        //temporary List to save the left crossers
        this.tempLeftCrossers=game.getLeftbank(); 
        
        this.rightCrossers=game.getRighttbank();
        
        if(game.getStory()==1) {
        	this.gameStrategy=new Story1();
        }
        else if(game.getStory()==2){
        	this.gameStrategy=new Story2();
        }
        
        //the initial crossers
        this.leftCrossers=gameStrategy.getInitialCrossers();
        
        //score
        score=new Score();
        score.setScore(game.getScore());
	}

	@Override
	public List<List<ICrosser>> solveGame() {
		return null;
	}
	
	////////////Extra methods than that in IRiverCrossingControlInterface /////////////
	public boolean win() {
		if(leftCrossers.size()==0) {
			load.delete();
			return true;
		}
		return false;
	}
	
	public boolean canResume()
    {
        File tempFile = new File("story.xml");
        boolean exists = false;
        exists = tempFile.exists();
        if(exists)
            return true;
        else
            return false;
    }
	
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	public String getErrorMessage() {
		return errorMessage;
	}
	
	public ICrossingStrategy getGameStrategy() {
		return gameStrategy;
	}
	
	public Score getScore() {
		return score;
	}
	
	
	public void setLeftCrossers(List<ICrosser> leftCrossers) {
		this.leftCrossers = leftCrossers;
	}
	
	public List<ICrosser> getTempLeftCrossers() {
		return tempLeftCrossers;
	}
	
	//temp
	public void print() {
		int i=0;
		System.out.println("\nLeft");

		for(i=0;i<leftCrossers.size();i++) {
			System.out.println(leftCrossers.get(i).getClass().getSimpleName());
		}
		
		System.out.println("\nRight");
		for(i=0;i<rightCrossers.size();i++) {
			System.out.println(rightCrossers.get(i).getClass().getSimpleName());
		}
	}
	
}
