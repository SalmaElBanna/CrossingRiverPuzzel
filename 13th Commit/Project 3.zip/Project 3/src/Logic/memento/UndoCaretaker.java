/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic.memento;
import java.util.Stack;

public class UndoCaretaker {
	
   private Stack <Memento> mementos = new Stack<>();
   
   public void addMemento(Memento m){
       mementos.push(m);
   }
   
   public Memento getMemento(){
       return mementos.pop();
   }
   public boolean empty(){
       return mementos.isEmpty();
    }
   
   public void clearStack() {
	   mementos.clear();
   }
}
