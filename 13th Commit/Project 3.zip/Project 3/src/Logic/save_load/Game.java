/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic.save_load;

import java.util.ArrayList;
import java.util.List;

import Logic.Receiver;
import Logic.Crossers.ICrosser;

public class Game {
    
    private int score;
    private boolean onLeftBank;
    private List<ICrosser> leftbank = new ArrayList<>();
    private List<ICrosser> rightbank = new ArrayList<>();
    private int story;
    
    Receiver receiver=Receiver.getInstance();
    
    public Game(int score, boolean position,List<ICrosser> leftbank,List<ICrosser> rightbank) {
        this.score = score;
        this.onLeftBank = position;
        this.leftbank = leftbank;
        this.rightbank = rightbank;
    }  
    
    //for undo and redo
    public Game() {
		this.score=receiver.getNumOfSails();
		this.onLeftBank=receiver.isBoatOnLeftBank();
		
		for(int i=0;i<receiver.getCrossersOnLeftBank().size();i++) {
			leftbank.add(receiver.getCrossersOnLeftBank().get(i));
		}
		
		for(int i=0;i<receiver.getCrossersOnRightBank().size();i++) {
			rightbank.add(receiver.getCrossersOnRightBank().get(i));
		}
 
    }
    
    //getters
    public List<ICrosser> getLeftbank() {
		return leftbank;
	}
    
    public List<ICrosser> getRighttbank() {
		return rightbank;
	}
    
    public int getScore() {
		return score;
	}
    
    public boolean isOnLeftBank() {
		return onLeftBank;
	}
    
    public int getStory() {
		return story;
	}
    
    //setter
    public void setStory(int story) {
		this.story = story;
	}
    
}
