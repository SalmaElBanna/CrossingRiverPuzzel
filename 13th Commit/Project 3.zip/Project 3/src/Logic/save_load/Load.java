package Logic.save_load;

import Logic.Crossers.Cabbage;
import Logic.Crossers.Carrot;
import Logic.Crossers.Farmer;
import Logic.Crossers.Fox;
import Logic.Crossers.Goat;
import Logic.Crossers.ICrosser;
import Logic.Crossers.Rabbit;
import Logic.Crossers.Wolf;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
public class Load {
	
    public Game getGprogress() throws ParserConfigurationException, SAXException, IOException
    {
  
            ArrayList<ICrosser> lbcrosser = new ArrayList<>();
            ArrayList<ICrosser> rbcrosser = new ArrayList<>();
            
            int score = 0;
            int j;
            boolean pos = false;
            
            Wolf f = new Wolf();
            Cabbage cab = new Cabbage();
            Goat go = new Goat();
            Farmer fa = new Farmer(50);
            
            File inputFile = new File("story.xml");
            if(inputFile==null)
                return null;
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            String mystring="";
            NodeList Listleft = doc.getElementsByTagName("leftchars");
            NodeList Listright = doc.getElementsByTagName("rightchars");
            NodeList which = doc.getElementsByTagName("story");
            for(j=0;j<which.getLength();j++)
            {
                Node node = which.item(j);
                if(node.getTextContent().equalsIgnoreCase("story2"))
                    mystring = "story2";
                else  mystring = "story1";
                    
            }
            
            if(mystring.equalsIgnoreCase("story1"))
            {
                
            for(j=0; j< Listleft.getLength() ; j++)
            {
                Node node = Listleft.item(j);
                String str = node.getTextContent();
                System.out.println(str+"\n");
                
                if(str.equalsIgnoreCase("Wolf"))
                    lbcrosser.add(f);
                else if(str.equalsIgnoreCase("Farmer"))
                    lbcrosser.add(fa);
                else if(str.equalsIgnoreCase("Cabbage"))
                    lbcrosser.add(cab);
                else if(str.equalsIgnoreCase("Goat"))
                    lbcrosser.add(go);
            }
            
            for(j=0; j< Listright.getLength() ; j++)
            {
                Node node = Listright.item(j);
                String str = node.getTextContent();
                System.out.println(str+"\n");
                if(str.equalsIgnoreCase("Wolf"))
                    rbcrosser.add(f);
                else if(str.equalsIgnoreCase("Farmer"))
                    rbcrosser.add(fa);
                else if(str.equalsIgnoreCase("Cabbage"))
                    rbcrosser.add(cab);
                else if(str.equalsIgnoreCase("Goat"))
                    rbcrosser.add(go);
            }
            
            NodeList placeplace = doc.getElementsByTagName("leftbankposition");
            
            for(j=0;j<placeplace.getLength();j++)
            {
                Node n = placeplace.item(j);
                String str = n.getTextContent();
                System.out.println(str+"\n");
                pos = str.equalsIgnoreCase("true"); 
            }
            
            NodeList mylist = doc.getElementsByTagName("numofmoves");
            
            for(j=0; j<mylist.getLength(); j++)
            {
                Node node = mylist.item(j);
                String str = node.getTextContent();
                score = Integer.parseInt(str);
                System.out.println(score+"\n");
            }

           Game game = new Game(score, pos,lbcrosser, rbcrosser);
           game.setStory(1);
           return game;
            }
                
            
            else
            { for(j=0; j< Listleft.getLength() ; j++)
             {
                Node node = Listleft.item(j);
                Element e = (Element)node;
                String str = node.getTextContent();
                
                if(str.equalsIgnoreCase("Wolf"))
                    lbcrosser.add(f);
                else if(str.equalsIgnoreCase("Farmer"))
                {
                    double d;
                    d= Double.parseDouble(e.getAttribute("weight"));
                    Farmer myf = new Farmer(d);
                    lbcrosser.add(myf);    
                }
                else if(str.equalsIgnoreCase("Cabbage"))
                    lbcrosser.add(cab);
                else if(str.equalsIgnoreCase("Goat"))
                    lbcrosser.add(go);
            }
            
            for(j=0; j< Listright.getLength() ; j++)
            {
                Node node = Listright.item(j);
                Element e = (Element)node;
                String str = node.getTextContent();
                if(str.equalsIgnoreCase("Wolf"))
                    rbcrosser.add(f);
                else if(str.equalsIgnoreCase("Farmer"))
                {
                   double d;
                   d= Double.parseDouble(e.getAttribute("weight"));
                   Farmer myfa = new Farmer(d);
                   rbcrosser.add(myfa);
                }
                else if(str.equalsIgnoreCase("Cabbage"))
                    rbcrosser.add(cab);
                else if(str.equalsIgnoreCase("Goat"))
                    rbcrosser.add(go);
            }
            
            NodeList placeplace = doc.getElementsByTagName("leftbankposition");
            
            for(j=0;j<placeplace.getLength();j++)
            {
                Node n = placeplace.item(j);
                String str = n.getTextContent();
                pos = str.equalsIgnoreCase("true"); 
            }
            
            NodeList mylist = doc.getElementsByTagName("numofmoves");
            
            for(j=0; j<mylist.getLength(); j++)
            {
                Node node = mylist.item(j);
                String str = node.getTextContent();
                score = Integer.parseInt(str);
            }

           Game game = new Game(score, pos,lbcrosser, rbcrosser);
           game.setStory(2);
           return game;
     
        }
    }
    public void delete()
    {
        File f = new File("story.xml");
        f.delete();
    }

}
   
