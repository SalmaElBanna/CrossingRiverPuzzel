/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic.save_load;

import Logic.*;
import Logic.Crossers.Cabbage;
import Logic.Crossers.Carrot;
import Logic.Crossers.Farmer;
import Logic.Crossers.Fox;
import Logic.Crossers.Goat;
import Logic.Crossers.ICrosser;
import Logic.Crossers.Rabbit;
import Logic.Crossers.Wolf;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


public class Progress2 {
    
    public static Game g;
  
    public Progress2(Game g) {
        Progress2.g = g; 
    }

    public Progress2() {
    }
    
    public void SaveProgress() throws TransformerException  {
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.newDocument();
            //
            // root element
            Element rootElement = doc.createElement("story2");
            doc.appendChild(rootElement);
            //
            // numofmoves element
            Element numofmoves = doc.createElement("numofmoves");
            rootElement.appendChild(numofmoves);
            //
            // lefttbankposition element
            Element leftbankposition = doc.createElement("leftbankposition");
            rootElement.appendChild(leftbankposition);

            numofmoves.setTextContent(Integer.toString(g.getScore()));
            
            Element story = doc.createElement("story");
            rootElement.appendChild(story);
            story.setTextContent("story2");

            //Position
            if (g.isOnLeftBank()) {
                leftbankposition.setTextContent("true");
            } else {
                leftbankposition.setTextContent("false"); 
            }
            //
            // getting characters on the right bank
            int i = 0;
            String weight = "weight";
            while (i < g.getRighttbank().size() ) {
            	
                Element rightchars = doc.createElement("rightchars");
                rightchars.setAttribute(weight, Double.toString(g.getRighttbank().get(i).getWeight()));
                
                if (g.getRighttbank().get(i) instanceof Fox) {
                    rightchars.setTextContent("Fox"); 
                } else if (g.getRighttbank().get(i) instanceof Cabbage) {
                    rightchars.setTextContent("Cabbage");
                } else if (g.getRighttbank().get(i) instanceof Carrot) {
                    rightchars.setTextContent("Carrots");
                } else if (g.getRighttbank().get(i) instanceof Farmer) {
                    rightchars.setTextContent("Farmer");
                } else if (g.getRighttbank().get(i) instanceof Goat) {
                    rightchars.setTextContent("Goat");
                } else if (g.getRighttbank().get(i) instanceof Wolf) {
                    rightchars.setTextContent("Wolf");
                } else if (g.getRighttbank().get(i) instanceof Rabbit) {
                    rightchars.setTextContent("Rabbit");
                }
                rootElement.appendChild(rightchars);
                i++; 
            }
            //
            // getting characters on the left bank
            i = 0;
            while (i < g.getLeftbank().size() ) {
                Element leftchars = doc.createElement("leftchars");
                leftchars.setAttribute(weight, Double.toString(g.getLeftbank().get(i).getWeight()));
                if (g.getLeftbank().get(i) instanceof Fox) {
                    leftchars.setTextContent("Fox");
                } else if (g.getLeftbank().get(i) instanceof Cabbage) {
                    leftchars.setTextContent("Cabbage");
                } else if (g.getLeftbank().get(i) instanceof Carrot) {
                    leftchars.setTextContent("Carrots");
                } else if (g.getLeftbank().get(i) instanceof Farmer) {
                    leftchars.setTextContent("Farmer");
                } else if (g.getLeftbank().get(i) instanceof Goat) {
                    leftchars.setTextContent("Goat");
                } else if (g.getLeftbank().get(i) instanceof Wolf) {
                    leftchars.setTextContent("Wolf");
                } else if (g.getLeftbank().get(i) instanceof Rabbit) {
                    leftchars.setTextContent("Rabbit");
                }
                rootElement.appendChild(leftchars);
                i++;
            }
            //
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File("story.xml"));
            transformer.transform(source, result);
            //
            // printing result
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(Progress.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
    
