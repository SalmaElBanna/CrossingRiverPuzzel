/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic.save_load;


import Logic.*;
import Logic.Crossers.Cabbage;
import Logic.Crossers.Carrot;
import Logic.Crossers.Farmer;
import Logic.Crossers.Fox;
import Logic.Crossers.Goat;
import Logic.Crossers.ICrosser;
import Logic.Crossers.Rabbit;
import Logic.Crossers.Wolf;

import javax.xml.parsers.*;
import javax.xml.transform.*;
import java.util.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


public class Progress {

    private Game g;

    public Progress(Game g) {
        this.g = g;
    }

    public void SaveProgress() throws TransformerException  {
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.newDocument();
            //
            // root element
            Element rootElement = doc.createElement("story1");
            doc.appendChild(rootElement);
            //
            // numofmoves element
            Element numofmoves = doc.createElement("numofmoves");
            rootElement.appendChild(numofmoves);
            //
            // lefttbankposition element
            Element leftbankposition = doc.createElement("leftbankposition");
            rootElement.appendChild(leftbankposition);

            numofmoves.setTextContent(Integer.toString(g.getScore()));
            
            //which story
            Element story = doc.createElement("story");
            rootElement.appendChild(story);
            story.setTextContent("story1");

            if (g.isOnLeftBank()) {
                leftbankposition.setTextContent("true");
            } else {
                leftbankposition.setTextContent("false"); 
            }
            //
            // getting characters on the right bank
            int i = 0;
            while (i < g.getRighttbank().size() ) {
                Element rightchars = doc.createElement("rightchars");
                
                 if (g.getRighttbank().get(i) instanceof Cabbage) {
                    rightchars.setTextContent("Cabbage");
                } else if (g.getRighttbank().get(i) instanceof Farmer) {
                    rightchars.setTextContent("Farmer");
                } else if (g.getRighttbank().get(i) instanceof Goat) {
                    rightchars.setTextContent("Goat");
                } else if (g.getRighttbank().get(i) instanceof Wolf) {
                    rightchars.setTextContent("Wolf");
                }
                rootElement.appendChild(rightchars);
                i++; 
            }
            //
            // getting characters on the left bank
            i = 0;
            while (i < g.getLeftbank().size() ) {
                Element leftchars = doc.createElement("leftchars");
                
                if (g.getLeftbank().get(i) instanceof Cabbage) {
                    leftchars.setTextContent("Cabbage");
                } else if (g.getLeftbank().get(i) instanceof Carrot) {
                    leftchars.setTextContent("Carrot");
                } else if (g.getLeftbank().get(i) instanceof Farmer) {
                    leftchars.setTextContent("Farmer");
                } else if (g.getLeftbank().get(i) instanceof Goat) {
                    leftchars.setTextContent("Goat");
                } else if (g.getLeftbank().get(i) instanceof Wolf) {
                    leftchars.setTextContent("Wolf");
                } 
                rootElement.appendChild(leftchars);
                i++;
            }
            //
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File("story.xml"));
            transformer.transform(source, result);
            //
            // printing result
            StreamResult consoleResult = new StreamResult(System.out);
            transformer.transform(source, consoleResult);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(Progress.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
