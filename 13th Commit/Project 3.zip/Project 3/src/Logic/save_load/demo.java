package Logic.save_load;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.ArrayList;

public class demo {
    public static void main(String[] args)
    {
        /**UndoCaretaker caretaker = new UndoCaretaker();
        Originator originator = new Originator();
        ArrayList<ICrosser> l = new ArrayList<>();
        ArrayList<ICrosser> r = new ArrayList<>();
        Farmer f = new Farmer(50);
        Cabbage cab = new Cabbage();
        Rabbit rab = new Rabbit();
        Fox w = new Fox();
        Carrots car = new Carrots();
        r.add(rab);
        l.add(f);
        l.add(cab);
        r.add(car);
        l.add(rab);
        Game g = new Game(5,true,l,r);
        Game g2 = new Game(7,false, r,l);
        Game g3 = new Game(8,true,l,r);
        Fox fo = new Fox();
        Lion lioness = new Lion();
        l.add(lioness);
        r.add(fo);
        Game g4 = new Game(9,false,r,l);
        originator.setState(g);
        originator.setState(g2);
        caretaker.addMemento(originator.saveStateToMemento());
        originator.setState(g3);
        caretaker.addMemento(originator.saveStateToMemento());
        originator.setState(g4);
        originator.restore(caretaker.getMemento());
        */
    }
    
}
