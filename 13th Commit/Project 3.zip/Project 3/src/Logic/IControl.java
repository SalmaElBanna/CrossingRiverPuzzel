package Logic;

import java.util.List;

import Logic.Crossers.ICrosser;
import Logic.Levels.ICrossingStrategy;

public interface IControl extends IRiverCrossingControl{
	
	public boolean win();
	
	public boolean canResume();
	
	public void setErrorMessage(String errorMessage) ;
	
	public String getErrorMessage();
	
	public ICrossingStrategy getGameStrategy();
	
	public Score getScore();
	
	public void setLeftCrossers(List<ICrosser> leftCrossers);
	
	public List<ICrosser> getTempLeftCrossers();

}
