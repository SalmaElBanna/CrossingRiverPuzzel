package Logic.Commands;

public interface Command {
	public void execute();
}
