Assumptions:



Detailed Division of Labor:

1.Jailan Mahmoud Hussein - 5733
a. in the ICrossers (Logic.Crossers package): Herbivore,Goat,Rabbit,Person and Farmer classes
b. in the ICrossingStrategies (Logic.Levels package): Story1 and StrategySetter
c. all the GUI except Story3Layout (GUI package): StartLayout,MainMenuLayout,LevelsLayout,GameLayout,Story1Layout,Story2Layout,WinLayout,SettingsLayout and Sprite classes
d. in the game engine (receiver class): newGame, resetGame,canMove,doMove,win,getInstructions,getCrossersOnRightBank,getCrossersOnLeftBank,isBoatOnLeftBank methods  
e. linking the logic with the gui 

  Design Patterns:
           Singelton
           Command
           Strategy                         

2.Jolie Sameh - 5865
a. in the ICrossers (Logic.Crossers package): Carnivore,Wolf and Fox classes
b. in the GUI (GUI package): Story3Layout and Sprite classes
c. validation of Story 3

3.Salma Elbanna - 5734
a. in the ICrossers (Logic.Crossers package): Plant,Carrot,Cabbage,Mother and Child classes
b. in the ICrossingStrategies (Logic.Levels package): Story2 and Story3 
c. Score, ScoreLabel and Stars classes (Logic package)
d. User Guide and Class Diagram

  Design Patterns:
          Observer 

4.Salma Salem - 5553
a. Undo and Redo (Logic.memento package)
b. loading and saving in xml files (Logic.save_load package)
c. in the game engine (receiver class): canUndo,canRedo,undo,redo,saveGame and loadGame methods

  Design Patterns:
         Memento 