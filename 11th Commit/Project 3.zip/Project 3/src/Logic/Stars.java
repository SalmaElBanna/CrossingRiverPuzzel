/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic;


public class Stars {
	
    private int stars;
    private int minNumOfSails;
    private int count;
    private String label;
    
    private Receiver receiver;
    
    public Stars() {
    	receiver=Receiver.getInstance();
        this.count=receiver.getNumOfSails();
       
       if( receiver.getGameStrategy().getClass().getSimpleName().equalsIgnoreCase("Story1")){
           minNumOfSails=7;
       }
       else if( receiver.getGameStrategy().getClass().getSimpleName().equalsIgnoreCase("Story2")){
           minNumOfSails=9;
       }
       
       if(count==minNumOfSails){
              increaseStars();
       }
       if(count>minNumOfSails)
              decreaseStars(minNumOfSails);   
       
    }
    
    public void increaseStars(){
     stars=3;
     label="Excellent!";
    }
    
    public void decreaseStars(int minNumOfSails){
    if((count-minNumOfSails)<3) {
        stars=2;
        label="Very Good!";
    }
    else {
        stars=1;
        label="Good";
       }
    } 
    
    public int getStars() {
		return stars;
	}
    
    public String getLabel() {
		return label;
	}
}
