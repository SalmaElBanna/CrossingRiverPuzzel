package GUI;

import java.awt.Dimension;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import Logic.Receiver;
import Logic.Stars;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class WinLayout {
	
	private Stage window;
	private Dimension screenSize;
	private Stage primaryStage;
	private Scene scene;
	private Stars stars;
	
	//Buttons
	Button okButton;
	
	//Layouts
	private MainMenuLayout mainMenuLayout;
	private LevelsLayout levelsLayout;
	
	private Receiver receiver;
	
	public WinLayout(Stage primaryStage,Dimension screenSize) {
		this.primaryStage=primaryStage;
		this.screenSize=screenSize;
		receiver=Receiver.getInstance();
	}
	
	public void display()
	{
		window=new Stage();
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle("Level Complete");
		window.initStyle(StageStyle.UNDECORATED); //to remove the minimize,maximize and close buttons
		
		Group group=new Group();
		
		stars=new Stars();
		
		//Labels
		Label performanceLabel=new Label(stars.getLabel());
		performanceLabel.setFont(Font.font(30));
		performanceLabel.setLayoutX(140);
		performanceLabel.setLayoutY(70);
		
		Label movesLabel=new Label("You completed the level in "+receiver.getNumOfSails()+" moves.");
		movesLabel.setFont(Font.font(16));
		movesLabel.setLayoutX(80);
		movesLabel.setLayoutY(150);
		
		//Button
		okButton=new Button("Ok");
		okButton.setFont(Font.font(16));
		okButton.setMinSize(80, 30);
		okButton.setLayoutX(170);
		okButton.setLayoutY(230);
		setButton();
		
		group.getChildren().addAll(performanceLabel,movesLabel,okButton);
		
		scene=new Scene(group,400,300);
		window.setScene(scene);
		window.showAndWait();
	}
	
	private void setButton() {
		okButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				try {
					levelsLayout=new LevelsLayout(primaryStage,screenSize);
					mainMenuLayout=new MainMenuLayout(primaryStage,screenSize);
					levelsLayout.setMainMenuLayout(mainMenuLayout);
					mainMenuLayout.setLevelsLayout(levelsLayout);
				} catch (IOException e) {
					e.printStackTrace();
				}
				Scene scene=levelsLayout.getScene();
				primaryStage.setScene(scene);
				window.close();
			}
			
		});
	}
	
	public void setLevelsLayout(LevelsLayout levelsLayout) {
		this.levelsLayout = levelsLayout;
	}
	

}
