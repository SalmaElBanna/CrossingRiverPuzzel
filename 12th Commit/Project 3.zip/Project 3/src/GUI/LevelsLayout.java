package GUI;

import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.imageio.ImageIO;

import Logic.Controller;
import Logic.Receiver;
import Logic.Commands.NewGameCommand;
import Logic.Levels.Story1;
import Logic.Levels.Story2;
import Logic.Levels.StrategySetter;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class LevelsLayout {
	
	private Stage stage;
	private Group group=new Group();
	private Scene scene=new Scene(group);
	private Dimension screenSize;
	
	//Images
	private Image backgroundImage;
	private Image story1Image;
	private Image story2Image;
	
	//ImageViews
	private ImageView image1;
	private ImageView image2;
	
	//Buttons
	Button returnButton;
	
	//Layouts
	SettingsLayout settingsLayout;
	MainMenuLayout mainMenuLayout;
	
	//Constructor 
	public LevelsLayout(Stage stage,Dimension screenSize) throws IOException {
		this.stage=stage;
		this.screenSize=screenSize;
		loadBackgroundImage();
		loadStoryImages();
		prepareScene();
		setEvents();
	}
	
	//preparing the scene
	public void prepareScene() {
		//adding the canvas
		Canvas canvas=new Canvas(screenSize.getWidth(),screenSize.getHeight()-70);
		group.getChildren().add(canvas);
		
		//getting the graphics context
		GraphicsContext gc=canvas.getGraphicsContext2D();
		
		/////////////Drawing////////////////
		gc.drawImage(backgroundImage, 0, 0);
		
		//drawing image of story 1
		image1=new ImageView(story1Image);
		image1.setLayoutX(200);
		image1.setLayoutY(200);
		group.getChildren().add(image1);
		
		//drawing image of story 2
		image2=new ImageView(story2Image);
		image2.setLayoutX(600);
		image2.setLayoutY(200);
		group.getChildren().add(image2);
		
		//adding the label
		Label label=new Label("Select a story");
		label.setFont(Font.font(35));
		label.setTextFill(Color.BLACK);
		label.setLayoutX(620);
		label.setLayoutY(70);
		group.getChildren().add(label);
		
		//adding the button
		returnButton=new Button("Return");
		try {
			returnButton.setGraphic(new ImageView(new Image(new FileInputStream("src\\resources\\Icons\\left-arrow.png"))));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		returnButton.setFont(Font.font(20));
		returnButton.setMinHeight(12);
		returnButton.setMinWidth(70);
		returnButton.setLayoutX(50);
		returnButton.setLayoutY(600);
		group.getChildren().add(returnButton);
		
	}
	
	
	//setting the events
	public void setEvents() {
		Receiver receiver=Receiver.getInstance();
		StrategySetter setter=new StrategySetter();
		Controller controller=new Controller();
		
		//return button
		returnButton.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				stage.setScene(mainMenuLayout.getScene());
				
			}
			
		});
		
		//story 1
		image1.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
         	@Override
			public void handle(MouseEvent event) {
         		setter.setStrategy(new Story1());
        		controller.setCommand(new NewGameCommand(receiver,setter.getStrategy()));
         		controller.performCommand();
         		try {	
         			mainMenuLayout=new MainMenuLayout(stage,screenSize);
         			settingsLayout=new SettingsLayout(stage,screenSize);
         			Story1Layout story1Layout=new Story1Layout(stage,screenSize);
	         	
	         		settingsLayout.setGameLayout(story1Layout);
	         		story1Layout.setSettingsLayout(settingsLayout);
	         		settingsLayout.setMainMenuLayout(mainMenuLayout);
	         		
	         		stage.setScene(story1Layout.getScene());
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
		});
		
		//story 2
		image2.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
         	@Override
			public void handle(MouseEvent event) {
         		setter.setStrategy(new Story2());
        	    controller.setCommand(new NewGameCommand(receiver,setter.getStrategy()));
         		controller.performCommand();
         		try {
         			mainMenuLayout=new MainMenuLayout(stage,screenSize);
         			settingsLayout=new SettingsLayout(stage,screenSize);
					Story2Layout story2Layout=new Story2Layout(stage,screenSize);
	         	
	         		settingsLayout.setGameLayout(story2Layout);
	         		story2Layout.setSettingsLayout(settingsLayout);
	         		settingsLayout.setMainMenuLayout(mainMenuLayout);
	         		
	         		stage.setScene(story2Layout.getScene());
         			
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
		});
	}
	
	//load storyImages
	public void loadStoryImages() throws IOException{
		BufferedImage bufferedImage1 = ImageIO.read(new File("src\\resources\\story1.png"));
		story1Image=SwingFXUtils.toFXImage(bufferedImage1, null);
		
		BufferedImage bufferedImage2 = ImageIO.read(new File("src\\resources\\story2.png"));
		story2Image=SwingFXUtils.toFXImage(bufferedImage2, null);
	}
	
	//load background image
	public void loadBackgroundImage() throws IOException {
		backgroundImage=new Image(new FileInputStream("src\\resources\\background.png")
				,screenSize.getWidth(),screenSize.getHeight(),false,false);
	}
	
	public Scene getScene() {
		return scene;
	}
	
	public void setMainMenuLayout(MainMenuLayout mainMenuLayout) {
		this.mainMenuLayout = mainMenuLayout;
	}
	

}
